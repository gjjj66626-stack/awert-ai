package ua.awert.ai

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.util.Base64
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun speak(text: String, language: String, rate: Double) {
            runOnUiThread {
                val engine = tts
                if (!ttsReady || engine == null) {
                    Toast.makeText(this@MainActivity, "Системне озвучення ще запускається", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val locale = Locale.forLanguageTag(language)
                val result = engine.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Toast.makeText(this@MainActivity, "Для цієї мови встанови голосові дані Android", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                engine.setSpeechRate(rate.toFloat().coerceIn(0.5f, 2.0f))
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "awert-tts")
            }
        }

        @JavascriptInterface
        fun stopSpeaking() {
            runOnUiThread { tts?.stop() }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                try {
                    val parsed = Uri.parse(url)
                    if (parsed.scheme == "https" || parsed.scheme == "http") {
                        startActivity(Intent(Intent.ACTION_VIEW, parsed))
                    } else {
                        Toast.makeText(this@MainActivity, "Посилання не підтримується", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Не вдалося відкрити посилання", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun saveVideo(base64: String, filename: String, mime: String) {
            Thread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, filename)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, "Download")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Не вдалося створити файл")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: throw IllegalStateException("Не вдалося записати файл")
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Відео збережено в папку Завантаження", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Помилка збереження відео: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript(
                "if(document.querySelector('#nav .active') && document.querySelector('#nav .active').dataset.page !== 'tts'){document.querySelector('[data-page=tts]').click();'handled'}else{'exit'}"
            ) { result ->
                if (result == "\"exit\"") finish()
            }
        } else super.onBackPressed()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
