# AWERT AI API — сервер для awert Ai.ua

## Що підтримує
- OpenAI Responses API
- Google Gemini `generateContent`
- Ollama `/api/chat` для open-source моделей

## Запуск локально
Потрібен Node.js 20+.
1. Скопіюй `.env.example` у `.env`.
2. Встав API-ключі у `.env` (тільки на сервері).
3. `npm install`
4. `npm start`
5. Перевір `http://localhost:8787/health`

Для Ollama встанови Ollama, завантаж модель, наприклад `ollama pull llama3.2`, і переконайся, що сервер API має доступ до `OLLAMA_URL`.

## Публічне розміщення
Розгорни сервер на VPS/хостингу з Node.js або Docker. Постав HTTPS через reverse proxy. У застосунку в Налаштуваннях вкажи `https://твій-домен`.

## Безпека
- Не клади OpenAI/Gemini ключі в Android APK або HTML.
- Установи довгий випадковий `AWERT_APP_TOKEN`.
- Для публічного релізу додай авторизацію користувачів, rate limiting, ліміти витрат і журналювання без секретів.
- Ollama — open-source локальна модель, але для її роботи потрібен сервер/комп'ютер із достатньою RAM/VRAM; це не означає безлімітний AI на самому телефоні.

## Android
Відкрий кореневу папку `awert-ai-universal` в Android Studio, синхронізуй Gradle та створи APK через Build > Build APK(s). Потрібні Android SDK 35 і JDK 17.
