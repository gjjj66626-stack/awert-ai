import express from "express";
import cors from "cors";
import helmet from "helmet";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: true }));
app.use(express.json({ limit: "1mb" }));

const PORT = Number(process.env.PORT || 8787);
const SYSTEM = "Ти — AWERT AI, помічник для створення якісного контенту. Відповідай конкретно, структуровано, без вигаданих фактів. Якщо факт не впевнений — познач це. Дотримуйся мови, заданої користувачем.";

function taskInstruction(task, language) {
  const lang = ({uk:"українською",en:"англійською",ru:"російською",pl:"польською"})[language] || "мовою користувача";
  const tasks = {
    shorts: "Створи динамічний сценарій YouTube Shorts/TikTok з сильним гачком у перші 2 секунди, логічним розвитком і закликом до дії. Не вигадуй біографічні факти.",
    seo: "Створи 5 сильних назв, короткий опис і релевантні хештеги. Не обіцяй гарантовані перегляди.",
    translate: "Переклади точно, зберігаючи сенс, стиль і формат.",
    rewrite: "Покращи текст, зроби його ясним, природним і виразним, не змінюй факти.",
    general: "Дай корисну й точну відповідь на запит користувача."
  };
  return `${SYSTEM}\nМова відповіді: ${lang}.\nЗавдання: ${tasks[task] || tasks.general}`;
}

async function callOpenAI(prompt, instructions) {
  if (!process.env.OPENAI_API_KEY) throw new Error("На сервері не задано OPENAI_API_KEY");
  const response = await fetch("https://api.openai.com/v1/responses", {
    method:"POST",
    headers:{ "Authorization":`Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type":"application/json" },
    body:JSON.stringify({ model:process.env.OPENAI_MODEL || "gpt-6-astra", instructions, input:prompt })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `OpenAI API помилка ${response.status}`);
  const text = (data.output || []).flatMap(x=>x.content || []).filter(x=>x.type==="output_text").map(x=>x.text).join("\n");
  return text || data.output_text || "Порожня відповідь OpenAI";
}

async function callGemini(prompt, instructions) {
  if (!process.env.GEMINI_API_KEY) throw new Error("На сервері не задано GEMINI_API_KEY");
  const model=process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`,{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({systemInstruction:{parts:[{text:instructions}]},contents:[{role:"user",parts:[{text:prompt}]}]})
  });
  const data=await response.json();
  if(!response.ok) throw new Error(data.error?.message || `Gemini API помилка ${response.status}`);
  return (data.candidates?.[0]?.content?.parts || []).map(p=>p.text || "").join("\n") || "Gemini не повернув текст.";
}

async function callOllama(prompt, instructions) {
  const url=(process.env.OLLAMA_URL || "http://127.0.0.1:11434").replace(/\/+$/,"");
  const response=await fetch(`${url}/api/chat`,{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({model:process.env.OLLAMA_MODEL || "llama3.2",stream:false,messages:[{role:"system",content:instructions},{role:"user",content:prompt}]})
  });
  const data=await response.json();
  if(!response.ok) throw new Error(data.error || `Ollama помилка ${response.status}`);
  return data.message?.content || "Ollama не повернула текст.";
}

app.get("/health",(_req,res)=>res.json({ok:true,service:"AWERT AI API",providers:["openai","gemini","ollama"]}));
app.post("/api/generate",async(req,res)=>{
  try {
    const token=process.env.AWERT_APP_TOKEN;
    if(token && req.get("x-awert-token") !== token) return res.status(401).json({error:"Невірний токен застосунку"});
    const {provider="openai",task="general",language="uk",prompt=""}=req.body || {};
    if(typeof prompt!=="string" || !prompt.trim()) return res.status(400).json({error:"Порожній запит"});
    if(prompt.length>12000) return res.status(413).json({error:"Запит задовгий (максимум 12000 символів)"});
    const instructions=taskInstruction(task,language);
    let text;
    if(provider==="openai") text=await callOpenAI(prompt,instructions);
    else if(provider==="gemini") text=await callGemini(prompt,instructions);
    else if(provider==="ollama") text=await callOllama(prompt,instructions);
    else return res.status(400).json({error:"Невідомий AI-провайдер"});
    res.json({provider,text});
  } catch(e) {
    console.error("AWERT API:",e.message);
    res.status(502).json({error:e.message || "Помилка AI-провайдера"});
  }
});
app.listen(PORT,"0.0.0.0",()=>console.log(`AWERT AI API listening on ${PORT}`));
